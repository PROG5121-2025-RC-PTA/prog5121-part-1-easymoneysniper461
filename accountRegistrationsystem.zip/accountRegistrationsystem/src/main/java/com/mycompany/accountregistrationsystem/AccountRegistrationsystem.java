/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.accountregistrationsystem;
import java.util.Scanner;
/**
 *
 * @author Leago George ST10467742
 */
public class AccountRegistrationsystem {

    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
       
       // username contains five characters long and underscore
       String registeredUsername = "";
       // password contain eight characters, a captial letter, a number and special character 
       String registeredPassword = "";
       
       System.out.println("=== Welcome to the registration page ===");
       
       // Registration
       System.out.println(" Register a username ");
       // Check if username already exists
        if (users.containsKey(registeredUsername)) {
            System.out.println("Username already taken!");
            return;
        }
       registeredUsername = scanner.nextLine();
       
       System.out.print(" Register a password ");
       // Basic password validation (at least 6 characters)
        if (password.length() < 6) {
            System.out.println("Password must be at least 6 characters long!");
            return;
        }
       registeredPassword = scanner.nextLine();
       
       System.out.println(" \nRegistration successful! ");
       System.out.println(" Please login to continue ");
       
       
       
       
       
       
       
      
        
    }
}    
    



