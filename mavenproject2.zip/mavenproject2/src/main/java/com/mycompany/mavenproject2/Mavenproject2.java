/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;
import javax.swing.JOptionPane;
import java.util.regex.*;
/**
 *
 * @author Leago George
 */
public class Mavenproject2 {
    public static boolean isValidUsername(String username){
        return username.contains("_") && username.length() <=5;
    }
    
    public static boolean isValidPassword(String password) {
        return password.length() >=8 &&
                Pattern.compile("[A-Z]").matcher(password).find() &&
                Pattern.compile("[0-9]").matcher(password).find() &&
                Pattern.compile("[^a-zA-Z0-9]").matcher(password).find();
    }
    
    public static boolean isValidCellphone(String cellphone) {
        return cellphone.startsWith("+27 or 0") && cellphone.length() <=13;
    }
    
    public static void main(String[] args) {
        // Registration
        String username = JOptionPane.showInputDialog("Enter a username:");
        if (isValidUsername(username)) {
            JOptionPane.showMessageDialog(null, "Username is successful");
        } else {
            JOptionPane.showMessageDialog(null, "Username is unsuccessful, ensure that username contains an underscore and no more than 5 characters in length");
            return;
        }
        
        String password = JOptionPane.showInputDialog("Enter a password");
        if (isValidPassword(password)) {
            JOptionPane.showMessageDialog(null, "Password successful");
        } else {
            JOptionPane.showMessageDialog(null, "Password unsuccessful, ensure password contains at least 8 characters, contain a capital letter, contain a number, and contain a special character");
            return;
        }
        
        String cellphone = JOptionPane.showInputDialog("Enter cellphone (with +27 or 0):");
        if (isValidCellphone(cellphone)) {
            JOptionPane.showInternalMessageDialog(null, "Cellphone number successful");
        } else {
            JOptionPane.showInternalMessageDialog(null, "Cellphone number unsuccessful, ensure number contains international code");
            return;
        }
        
        // Login
        String loginUsername = JOptionPane.showInputDialog("Login - Enter usernmae:");
        String loginPassword = JOptionPane.showInputDialog("Login - Enter password:");
        
        if (loginUsername.equals(username) && loginPassword.equals(password)) {
            JOptionPane.showMessageDialog(null, "Login successful!");
        } else {
            JOptionPane.showMessageDialog(null, "Login unsuccessful!");
        }
        
    }
    
}

    








